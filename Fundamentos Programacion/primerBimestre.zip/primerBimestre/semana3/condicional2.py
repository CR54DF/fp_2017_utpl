################ Proyecto Primer Biestre###############

### Nombre: Cristhyan Bastidas

# variables
numero = 11

# condicional if
if numero >= 10 and numero <= 11 :
	# Presentar datos
	print "Aprobado con:  %d" % numero
# caso contrario
else:
	#presentar datos
	print "reprobado con: %d" % numero
