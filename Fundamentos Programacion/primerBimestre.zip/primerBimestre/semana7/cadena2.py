################ Proyecto Primer Biestre###############

### Nombre: Cristhyan Bastidas

# variables
cadena = ""
suma1 = 0
suma2 = 0
cadena = cadena + "%s\t\t%s\n" % ("valor","resultado")
# ciclo for
for contador in range(1,11):
	suma1 = suma1 + contador
	auxiliar = contador + 10
	auxiliar = int(auxiliar)
	suma2 = suma2 + auxiliar
	cadena = cadena + "%d\t\t%d\n" % (contador,auxiliar)
	cadena = cadena + "%d\t\t%d\n" % (suma1,suma2)
	# impresion de datos
	print cadena