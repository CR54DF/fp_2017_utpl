################ Proyecto Primer Biestre###############

### Nombre: Cristhyan Bastidas


# ciclo for
for contador in range(1,11):
	# impresion de datos
	print "%d" % contador