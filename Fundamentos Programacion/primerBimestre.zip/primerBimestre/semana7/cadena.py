################ Proyecto Primer Biestre###############

### Nombre: Cristhyan Bastidas

cadena = ""
# ciclo for
for contador in range(1,11):
	# formula a resolver
	cadena = cadena + "%d\t\t%d\n" % (contador,contador+10)
	
	# presentasin de datos
	print cadena