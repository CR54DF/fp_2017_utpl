################ Proyecto Primer Biestre###############

### Nombre: Cristhyan Bastidas

# peticion de datos
tipo = raw_input("vertical: 1\n  horizontal: 2")
tipo = int(tipo)
# ciclo for
for contador in range(1,11):
	# primer condicional if
	if tipo == 1:
		print "%d\n" % contador

	# segundo condicional
	if tipo == 2:	
		#impresion de datos
		print "%d" % contador