################ Proyecto Primer Biestre###############

### Nombre: Cristhyan Bastidas
# peticion de datos


import math

radianes = raw_input("ingrese un numero en radianes")
radianes = float(radianes)
# formulas para calcular valores
tangente = math.sin(radianes)/math.cos(radianes) 
tangente = float(tangente)
cotangente = math.cos(radianes)/math.sin(radianes)
cotangente = float(cotangente)
secante = 1/math.cos(radianes)
secante = float(secante)
cosecante = 1/math.sin(radianes)
cosecante = float(cosecante)
# impresion de datos
respuesta = "tangente: " + str(tangente) + "\ncotangente" + str(cotangente) + "\nsecante: " + str(secante) + "\ncosecante: " + str(cosecante)
print respuesta