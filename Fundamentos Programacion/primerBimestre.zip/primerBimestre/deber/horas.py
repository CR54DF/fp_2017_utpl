################ Proyecto Primer Biestre###############

### Nombre: Cristhyan Bastidas

# peticion de datos 
horas = raw_input("Ingrese la cantidad de Horas: ")
horas = float(horas)
# ecuaciones para calcular valores
minutos = horas*60
minutos = float(minutos)
segundos = horas*3600
segundos = float(segundos)
dias = horas/24
dias = float(dias)
# impresion de datos
print "Horas: %d" % horas
print "Minutos: %d" % minutos
print "Segundos: %d" % segundos
print "dias: %d" % dias