################ Proyecto Primer Biestre###############

### Nombre: Cristhyan Bastidas

utilidad = 150
impuesto = 15

producto = raw_input("ingrese el nombre del producto: ")
productoC = raw_input("ingrese el costo del producto: ")
producto1 = str(producto)
producto2 = float(productoC)

(impuesto) = int(productoC) * 150 / 100
utilidad = int(productoC)* 15 / 100
productoC = utilidad + impuesto

salida = "nombre: " + producto1 + "\nprecio: " + str(producto2) + "\nimpuesto: " + str(impuesto) + "\nutilidad: " + str(utilidad)

print salida