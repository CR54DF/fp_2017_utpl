################ Proyecto Primer Biestre###############

### Nombre: Cristhyan Bastidas

# peticion de datos

largo = raw_input("ingrese el largo del terreno: ")
largo = float(largo)
ancho = raw_input("ingrese el ancho del terreno: ")
ancho = float(ancho)

# formula para calcular el area
area = largo + ancho
area = str(area)
# peticion del precio por teclado
precio = ("ingrese el precio del metro cuadrado: ")
precio = float(precio)
# formula para calcular el precio
precio = precio*area
# condicional if 
if area < 400:

	total = (precio-(precio*0.10))
	# impresion de datos
	print "Valor a pagar: %d" % total
else:
	# impresion de datos
	print "valor a pagar: %d" % precio