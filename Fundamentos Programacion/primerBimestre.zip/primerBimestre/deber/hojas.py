################ Proyecto Primer Biestre###############

### Nombre: Cristhyan Bastidas

# peticion de datos 
hojas = raw_input("Ingrese la cantidad de hojas de hielo: ")
hojas = int(hojas)
vigas = raw_input("Ingrese la cantidad de viguetas: ")
vigas = int(vigas)
armazones = raw_input("Ingrese la cantidad de Armazones: ")
armazones = int(armazones)
# peticion de costos
cosH = raw_input("ingrese el costo de las hojas de hielo: ")
cosH = float(cosH)
cosV = raw_input("Ingrese el costo de las viguetas: ")
cosV = float(cosV)
cosA = raw_input("Ingrese el costo de las armazones: ")
# eleccion de opciones
contado = raw_input("Ingrese\n1 Para contado: ")
contado = int(contado)
plaso = raw_input("Ingrese\n2 Para plaso: ") 
# condicional para pago al contado
if contado == 1 :
	cos1 = (cosH*armazones-(cosH*0.20))
	cos1 = float(cos1)
	cos2 = (cosV*vigas*(cosV*0.15))
	cos2 = float(cos2)
	cos3 = (cosA*armazones)
	cos3 = float(cos3)
	totalc = cos1 + cos2 + cos3
	totalc = float(totalc)
	totalt = (totalc-(totalc*0.7))
	# imprecion de datoos
	print "Contado: %d" % totalt
# condicional para pago a plasos
if plaso == 2:	
	cos1 = (cosH*armazones-(cosH*0.20))
	cos1 = float(cos1)
	cos2 = (cosV*vigas*(cosV*0.15))
	cos2 = float(cos2)
	cos3 = (cosA*armazones)
	cos3 = float(cos3)
	totalc = cos1 + cos2 + cos3
	totalc = float(totalc)
	#imprecion de datos
	print "Plasos: %d" % totalc
