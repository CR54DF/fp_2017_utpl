################ Proyecto Primer Biestre###############

### Nombre: Cristhyan Bastidas

# peticion de datos
costo = raw_input("ingrese el costo por metro cuadrado: ")
costo = float(costo)
ancho = raw_input("ingrese el ancho: ")
ancho = float(ancho)
longitud = raw_input("ingrese la longitud: ")
longitud = float(longitud)
# forula para calcular
costoT = costo * ancho * longitud
# impresion de resultados
print "costo: %d" % costoT