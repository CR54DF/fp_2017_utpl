################ Proyecto Primer Biestre###############

### Nombre: Cristhyan Bastidas

# peticion de datos
c = raw_input("ingrese el valor en celsius: ")
c =float(c)
# formula para transformar los grados
f = 9/5*c+32
f = float(f)

# inpresionde de datos
print "Grados Fahrenheir: %d" % f