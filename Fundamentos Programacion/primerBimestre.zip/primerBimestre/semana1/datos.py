################ Proyecto Primer Biestre###############

### Nombre: Cristhyan Bastidas

# variables
Nombre = "cristhyan"
apellido = "Bastidas"

# variable a presentar
Nombre1 = "Mi nombre es: " + Nombre + "\nMi apellido: " + apellido

# presentacion de datos 
print Nombre1
