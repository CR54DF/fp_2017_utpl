################ Proyecto Primer Biestre###############

### Nombre: Cristhyan Bastidas

""" datos a evaluar """
numero1 = 5
numero2 = 7
suma = 0

# solucionde del problema
suma = numero1 + numero2

# imprecion de datos
print suma