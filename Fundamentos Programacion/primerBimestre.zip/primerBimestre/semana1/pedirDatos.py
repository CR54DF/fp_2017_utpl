################ Proyecto Primer Biestre###############

### Nombre: Cristhyan Bastidas

# ingresar los valores
edad = input("Ingrese su edad: ")
altura = input("Ingrese su altura: ")

# definir variables
edad = int(edad)
altura = float(altura)

valor = "mi edad es: %d \n mi estatura: %2.f" % (edad , altura)

# presentar datos
print valor