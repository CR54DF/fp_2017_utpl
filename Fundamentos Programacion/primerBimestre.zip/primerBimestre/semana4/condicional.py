################ Proyecto Primer Biestre###############

### Nombre: Cristhyan Bastidas


# variable a usar
valor = 1

# condicional hasta que se umpla la la condicion
while valor <= 5:
	#impresion de datos
	print"valor: %d" %valor
	valor = valor + 1 
