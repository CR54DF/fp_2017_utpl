################ Proyecto Primer Biestre###############

### Nombre: Cristhyan Bastidas

# declaracion de variables

suma = 0
bandera = True
m = -1
cadena = ""
# uso de while
while(bandera):

# peticion de datos
	valor = raw_input("ingrese el valor a sumar: ")
	valor = int(valor)
	suma = suma + valor
	m = raw_input("ingrese -1 para salir: ")
	m = int(m)
	cadena2 = "valor a sumar" , valor
	cadena = valor + cadena2 +"\n"
	valor = str(valor)
	cadena2 = str(cadena2)
	# a esta condicion la usamos para salir 
	if m==-1:
		bandera = False
# presentacion de datos
print "valores sumados: %d" % cadena
print "valores sumados: %d" % suma
