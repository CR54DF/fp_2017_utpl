################ Proyecto Primer Biestre###############

### Nombre: Cristhyan Bastidas


# peticion de datos
nombre = raw_input("ingrese sus nombres: ")
apellido = raw_input("ingrese sus apellidos: ")
ciudad = raw_input("ingrese su ciudad: ")
edad = raw_input("ingrese su edad: ")
 
salida = "\n nombre:  \n " + nombre + "\n su apellido: \n" + apellido + "\n  su ciudad:  \n" + ciudad + "\n su edad: \n" + str(edad)
# salida de datos
print salida