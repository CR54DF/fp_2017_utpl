################ Proyecto Primer Biestre###############

### Nombre: Cristhyan Bastidas

# variables

numero= 9

# condicional a evaluar
if numero >= 10 :

	# presentar los datos
	print "Aprobado con:  %d" % numero
# condicional para evaluar la otra opcion
else:
	# pesentar datos de la segunda condicion
	print "Reprobado con:  %d"	% numero


	