################ Proyecto Primer Biestre###############

### Nombre: Cristhyan Bastidas

# pedir datos
print "ecuacion a resolver \n x = 10 / a + b - 3 * c"
a = int(input("ingrese el valor de a: "))

b = int(input("ingrese el valor de b: "))

c = int(input("ingrese el valor de c: "))
 
# presentar datos

print "el resultado es"

print (10/a+b-3*c)