################ Proyecto Primer Biestre###############

### Nombre: Cristhyan Bastidas

# formula a evaluar
print "\nx =3x^2+7-15 "

## peticion de datos
x = raw_input("Ingrese el valor de:\n(X)")
x = float(x)
y = (3*x*x) + (7*x) - 15
y = float(y)

# presentacion de datos
print "El valor de Y: \n\t%s" % y
