################ Proyecto Primer Biestre###############

### Nombre: Cristhyan Bastidas

# peticion de datos
unidades = raw_input("Ingrese las unidades producidas: ")
unidades= int(unidades)
# formula para calcular el costo
costo = unidades * 3.5 + 10700

# impresion del costo
print "Unidades: %d" % unidades
print "Valor: %d" % costo
