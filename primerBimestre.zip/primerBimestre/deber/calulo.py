################ Proyecto Primer Biestre###############

### Nombre: Cristhyan Bastidas

# formula a calcular
print "y = (3 * x) + 6"
print "y = (x * x) + 6"

# peticion de datos
x = raw_input("ingrese el valo de (X): ")
x = float(x)

# condicional if
if x < 0:
	#formula primer concion
	y = (3*x)+(6)
	y = float(y)
	# impresion de datos
	print "valor: %d" % y
	# segundo condicional if
if x >= 0:	
	# formula sgunda condicion
	y =(x*x)+(6)
	# impresion de datos
	print "valor: %d" % y