################ Proyecto Primer Biestre###############

### Nombre: Cristhyan Bastidas

# peticion de datos
a = raw_input("Igrese el nombre del Articulo:\n ")
a = str(a)
p = raw_input("Ingrese el costo de Producto:\n ")
p = float(p)
c = raw_input("Ingrese la cantidad de la Compra:\n ")
c = float(c)
p = p * p

# condicional if
if c > 50 :
	total = (p-(p*0.15))
	total = float(total)
	print "Producto: %d" + a
	print "Valor: %d" % total
else:
	print "producto: %d" + a
	print "Valor: %d" % p 