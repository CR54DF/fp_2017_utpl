################ Proyecto Primer Biestre###############

### Nombre: Cristhyan Bastidas


print "ecuacion: \ny = (3*x*x)+(7*x)-15"
valor = raw_input("Ingrese el valor de X: ")
valor1 = float(valor)
x=0
# formula para calcular valor
y = (3*x*x) + (7*x)-15
#imprimir los resultados
print y