################ Proyecto Primer Biestre###############

### Nombre: Cristhyan Bastidas

# variables
suma = 0
bandera = True
m = -1

# uso de while
while(bandera):

# peticion de datos
	valor = raw_input("ingrese el valor a sumar: ")
	valor = int(valor)
	suma = suma + valor
	m = raw_input("ingrese -1 para salir: ")
	m = int(m)
	# a esta condicion la usamos para salir 
	if m==-1:
		bandera = False
# presentacion de datos
print "valores sumados: %d" % suma
