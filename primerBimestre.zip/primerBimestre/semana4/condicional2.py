################ Proyecto Primer Biestre###############

### Nombre: Cristhyan Bastidas
contador = 1
suma = 0
valor =8
# peticion de datos
l = raw_input("ingresa un limite: ")
l = float(l)

# condicional while 
while contador <= l:
	raw_input = ("ingrese un valor: ")
	valor = float(valor)
	suma = suma + valor
	contador = contador + 1
	# impresion de datos
	print "suma: %d" % suma
	
	

