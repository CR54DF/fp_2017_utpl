/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clase3;

import java.util.Scanner;

/**
 *
 * @author Dell-5567
 */
public class Principal {
    
    public static void main(String[] args) {
        Scanner e = new Scanner(System.in);
        Operacion i = new Operacion();
        System.out.println("ingrese valor1: ");
        double valor1 = e.nextDouble();
        System.out.println("ingrese valor2: ");
        double valor2 = e.nextDouble();
        System.out.println("Ingrese una opcion:\n1 Suma:\n2 Resta:\n3 Multiplicacion:\n4 Division:   ");
        int opcion = e.nextInt();
        i.impresion(valor1, valor2, opcion);
    }
    
}
