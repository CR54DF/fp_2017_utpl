/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clase3;

import java.util.Scanner;

/**
 *
 * @author Dell-5567
 */
public class Numeros2 {
    
    public static void main(String[] args) {
        Presenta imprimir = new Presenta();
        Scanner e = new Scanner(System.in);
        
        System.out.println("Ingrese su Nombre: ");
        String nombre = e.nextLine();
        System.out.println("Tipo de reporte 1.  2. ");
        int tipo = e.nextInt();
        imprimir.presenta_impresion(tipo, nombre);
    }
}
