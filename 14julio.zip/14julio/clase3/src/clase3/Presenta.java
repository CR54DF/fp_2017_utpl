/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clase3;

/**
 *
 * @author Dell-5567
 */
public class Presenta {

    public void presenta_mayuscula(String valor) {
        System.out.printf("Nombre ingresado\n\t%s\n", valor.toUpperCase());

    }

    public void presenta_minuscula(String valor) {
        System.out.printf("Nombre ingresado\n\t%s\n", valor.toLowerCase());
    }

    public void presenta_impresion(int opcion, String valor2) {
        if (opcion==1) {
            presenta_mayuscula(valor2);
        }else{
            if (opcion==2) {
                presenta_minuscula(valor2);
                
            }else{
                System.out.println("No hay reporte");
            }
        }

    }
}
