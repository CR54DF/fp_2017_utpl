/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clase3;

/**
 *
 * @author Dell-5567
 */
public class Operacion {

    public void impresion(double val1, double val2, int opcion) {
        if (opcion == 1) {
            presenta_suma(val1, val2);
        } else {
            if (opcion == 2) {
                presenta_resta(val1, val2);
            } else {
                if (opcion == 3) {
                    presenta_multiplicacion(val1, val2);
                } else {
                    if (opcion == 4) {
                        presenta_division(val1, val2);
                    } else {
                        System.out.println("no existe");
                    }
                }
            }
        }

    }

    public void presenta_suma(double val1, double val2) {
        double suma = val1 + val2;
        System.out.printf("la suma%f mas %f\nes igual a \n\t%f", val1, val2, suma);
    }

    public void presenta_resta(double val1, double val2) {
        double resta = val2 - val1;
        System.out.printf("la resta%f mas %f\n es igual a \n\t%f", val1, val2, resta);
    }

    public void presenta_multiplicacion(double val1, double val2) {
        double multiplicacion = val1 * val2;
        System.out.printf("la multiplicacion%f mas %f\nes igual a \n\t%f", val1, val2, multiplicacion);
    }

    public void presenta_division(double val1, double val2) {
        double division = val1 / val2;
        System.out.printf("la division%f mas %f\nes igual a \n\t%f", val1, val2, division);
    }
}
